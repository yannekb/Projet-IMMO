<?php

namespace IMMO\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IMMOUserBundle extends Bundle
{
}
