<?php

namespace IMMO\UserBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use IMMO\UserBundle\Entity\Clients;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\Request;

class ClientsController extends Controller
{
    public function addAction(Request $request)
    {
      // On crée un objet client
      $client = new Clients();

      // On crée le FormBuilder grâce au service form factory
      $form = $this->get('form.factory')->createBuilder(FormType::class, $client)
        ->add('name', TextType::class)
        ->add('first_name', TextType::class)
        ->add('address', TextType::class)
        ->add('phone_number', TextType::class)
        ->add('email', EmailType::class)
        ->add('password', PasswordType::class)
        ->add('enregistrer', SubmitType::class)
        ->getForm()
      ;

      if($request->isMethod('POST')) {
        $form->handleRequest($request);

        if($form->isValid()) {
          $em = $this->getDoctrine()->getManager();
          $em->persist($client);
          $em->flush();

          $request->getSession()->getFlashBag()->add('checked-in', 'Vous avez été enregistré');

          return $this->redirectToRoute('immo_user_homepage');
        }
      }

        return $this->render('IMMOUserBundle:Clients:index.html.twig', array('form' => $form->createView()));
    }
}
